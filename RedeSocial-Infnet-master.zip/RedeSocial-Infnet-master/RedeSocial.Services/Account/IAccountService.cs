﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RedeSocial.Services.Account
{
    public interface IAccountService
    {

    }
}
