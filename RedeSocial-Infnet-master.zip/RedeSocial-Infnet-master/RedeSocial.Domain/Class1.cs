﻿using System;

namespace RedeSocial.Domain
{
    public class Class1
    {
    }
}
