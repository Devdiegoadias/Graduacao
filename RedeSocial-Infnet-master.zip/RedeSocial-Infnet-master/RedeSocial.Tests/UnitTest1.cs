using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RedeSocial.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
