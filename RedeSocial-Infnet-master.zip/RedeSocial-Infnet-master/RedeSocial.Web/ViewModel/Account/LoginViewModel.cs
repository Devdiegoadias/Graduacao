﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RedeSocial.Web.ViewModel.Account
{
    public class LoginViewModel
    {
        public String UserName { get; set; }

        public String Password { get; set; }
    }
}
