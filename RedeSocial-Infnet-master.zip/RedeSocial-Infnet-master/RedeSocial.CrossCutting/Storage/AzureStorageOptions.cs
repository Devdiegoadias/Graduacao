﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RedeSocial.CrossCutting.Storage
{
    public class AzureStorageOptions
    {
        public string ConnectionString { get; set; }
    }
}
