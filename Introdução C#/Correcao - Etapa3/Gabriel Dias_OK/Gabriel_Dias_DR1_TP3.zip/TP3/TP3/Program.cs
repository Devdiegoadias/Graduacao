﻿using System;
using System.Collections.Generic;
using TP3.Classes;
namespace TP3
{
    class Program
    {
        static void Main(string[] args)
        {
            Opcoes.Menu();
            Console.ReadKey();
        }
    }
}
