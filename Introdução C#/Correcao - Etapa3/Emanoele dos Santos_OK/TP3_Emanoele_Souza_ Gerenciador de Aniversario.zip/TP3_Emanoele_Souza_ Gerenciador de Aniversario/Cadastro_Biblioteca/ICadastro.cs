﻿
namespace Cadastro_Biblioteca
{
    interface ICadastro
    {
        void CadastroPessoa();
    }
}
