﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3_CS
{
    public class Pessoa
    {
        public string nome { get; set; }
        public string sobrenome { get; set; }
        public DateTime dataAniversario { get; set; }
    }
}
