﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Etapa6
{
    internal abstract class Eletronico
    {
        private readonly string _nome;
        private readonly Voltagem _voltagem;

        internal enum Voltagem
        {
            v110 = 110,
            v220 = 220
        }

        internal Eletronico(string nome, Voltagem voltagem)
        {
            _nome = nome;
            _voltagem = voltagem;
        }

        internal abstract void Ligar();
        internal abstract void Desligar();

        internal virtual void Carregar()
        {
            Console.WriteLine("carregando pai");
        }

    }

    internal class Celular : Eletronico
    {
        internal enum Fabricante
        {
            Samsung = 1,
            Apple = 2,
            CCE = 3,
            Xiaomi = 4
        }

        internal Celular(string nome, Voltagem voltagem, Fabricante fabricante) : base(nome, voltagem)
        {

        }

        internal override void Ligar() { }
        internal override void Desligar() { }

        internal override void Carregar()
        {
            Console.WriteLine("carregando filho");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Eletronico e1 = new Eletronico("aaa", Eletronico.Voltagem.v110); //classe abstrata nao pode ser instanciada            

            Celular c1 = new Celular("aaa", Eletronico.Voltagem.v110, Celular.Fabricante.Apple);
            Celular c2 = new Celular("aaa", Eletronico.Voltagem.v110, Celular.Fabricante.Apple);
            Celular c3 = new Celular("aaa", Eletronico.Voltagem.v110, Celular.Fabricante.Apple);

            List<Celular> lista = new List<Celular>();
            lista.Add(c1);
            lista.Add(c2);
            lista.Add(c3);

            IEnumerable inumerable = lista;
            ICollection icollection = lista;
            IList ilist = lista;

            foreach (Celular c in inumerable)
            {
                c.Carregar();
            }

            c1.Carregar();

            Console.ReadLine();

        }
    }
}
