﻿using System;
using Etapa6;

namespace Etapa6_2
{
    class Program
    {
        static void Main(string[] args)
        {
           // Etapa6
        }
    }
}
