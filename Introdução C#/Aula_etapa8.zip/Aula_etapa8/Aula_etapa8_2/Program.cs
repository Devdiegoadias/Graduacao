﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using BibliotecaDeClasses.Classes;

namespace Aula_etapa8_2
{
    public class CalculaPreco
    {
        public int CalculoFinal(int quantidade, int preco)
        {
            return quantidade * preco;
        }
    }
    
    public static class MetodosExtendidos
    {
        public static bool EmailValido(this string email)
        {
            var regex = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";
            bool isValid = Regex.IsMatch(email, regex, RegexOptions.IgnoreCase);
            return isValid;
        }

        public static int MultiplicarPor2(this int inteiro)
        {
            return inteiro * 2;
        }

        public static float MultiplicarPor3(this float f)
        {
            return f * 3;
        }

        public static int PrecoBlackFriday(this CalculaPreco p, int preco, int quantidade)
        {
            return p.CalculoFinal(preco, quantidade) - 100;
        }
    }
    class Program
    {

        static void Main(string[] args)
        {
            string[] diretorios = Directory.GetDirectories(@"C:\");
            string[] arquivos = Directory.GetFiles("C:\\__diego","*.pdf", SearchOption.AllDirectories);            
            bool existaDiretorio = Directory.Exists("C:\\___diego");
            
            if(File.Exists(@"C:\__diego\download.jpg"))
            {
                FileInfo infoarquivo = new FileInfo(@"C:\__diego\download.jpg");
                Console.WriteLine("Nome Completo: " + infoarquivo.FullName);
                Console.WriteLine("Data de Criação: " + infoarquivo.CreationTime);
                Console.WriteLine("Tamanho:" + infoarquivo.Length);
                Console.WriteLine("Ultimo Acesso: "+infoarquivo.LastAccessTime);
            }


            //Desafio:
            //CONTANDO QTOS ARQUIVOS TEM EM CADA PASTA DE UM DETERMINADO DIRETORIO


            string email = "aaaaa@@aaa..com";

            email.EmailValido();

            int inteiro = 5;            

            inteiro.MultiplicarPor2();

            float variavelFloat = 9;

            variavelFloat.MultiplicarPor3();


            CalculaPreco cp = new CalculaPreco();

            int totalDesconto = cp.PrecoBlackFriday(1000, 2);

            Console.WriteLine("Preco com desconto é:" + totalDesconto);

            var g1 = new Galinha();
            var g2 = new Galinha();
            var a1 = new Aguia();
            var a2 = new Aguia();
            var objDumbo = new Dumbo();

            IAves interfaceIAves = g1;

            //Interface IAves;
            IAves iVoar = a1;
            iVoar.Comer();
            iVoar = g1;
            iVoar.Comer();

            ITerrestre ITerr = a1;

            ITerr.Andar();
            ITerr.Morar();

            ITerr = g1;
            ITerr.Andar();

            //A interface So vai receber informações que PEDE !
            //Quais , professor ? 
            //As que ela solicita em sua declaração
            ITerr = objDumbo;
            ITerr.Andar();
            ITerr.Morar();

            iVoar = objDumbo;
            iVoar.Voar();


            //Dev lambão quis dar um nome para o repositório..... :-0
            RepositorioClassConcreta repConcreta = new RepositorioClassConcreta();
            repConcreta.ProcessarInclusao("nomeRepositorio");

            //////////////////////////////
            //OUTRO DEV MAIS SAFO PERCEBEU QUE PODE TRABALHAR COM INTERFACE....
            //////////////////////////////

            //aqui eu tenho uma variavel em que a classe IMPLEMENTA o que RepositorioInterface pede no construtor
            var repositorio = new Repositorio("etapa8");

            RepositorioInterface repInterface = new RepositorioInterface(repositorio);
            repInterface.ProcessarInclusao();


            //23/11/2021
            // 1- Erro qdo tentamos instanciar uma classe abstrata e uma interface
            //var objClasseAbstrata = new Eletronico();
            //var objInterface = new IRepositorio();

            //2 - Interface funciona como contrato, e quem a implementa REESCREVE seus métodos (override).
            //IRepositorio repositorioInterface = new Repositorio("etapa8");
            //repositorioInterface.Adicionar();

            //3 - No .net, Herdamos somente de uma classe (abstrata ou não), porém podemos implementar várias interfaces
            //public class Televisao:Eletronico, IRepositorio, IReadOnlyList, IServiceProvider, ICloneable

        }



    }
}
