﻿using System;
using System.Collections.Generic;
using BibliotecaDeClasses.Classes;

namespace Aula_etapa8
{
   
    //Escondendo métodos - New
    public class ClasseBase
    {
        public virtual void Metodo1()
        {
            Console.WriteLine("ClasseBase Metodo1");
        }

        public virtual void Metodo2()
        {
            Console.WriteLine("ClasseBase Metodo2");
        }

        public virtual void Metodo3()
        {
            Console.WriteLine("ClasseBase Metodo3");
        }
    }

    public class ClasseDerivada : ClasseBase
    {
        public override void Metodo1()
        {
            Console.WriteLine("ClasseDerivada Metodo1");
        }

        public override void Metodo2()
        {
            Console.WriteLine("ClasseDerivada Metodo2");
        }

        public override void Metodo3()
        {
            Console.WriteLine("ClasseDerivada Metodo3");
        }
    }

    //Operador sealed

    public class ClasseBase2
    {
        public virtual void Metodo1()
        {
            Console.WriteLine("ClasseBase2 Metodo1");
        }
    }

    public  class ClasseDerivada1 : ClasseBase2
    {
        public override void Metodo1()
        {
            Console.WriteLine("ClasseDerivada1 Metodo1");
        }
    }

    public  class ClasseDerivada7 : ClasseDerivada1
    {
        public  override void Metodo1()
        {
            Console.WriteLine("ClasseDerivada7 Metodo1");
        }
    }

    public class ClasseDerivada8:ClasseDerivada7
    {
        public override void Metodo1()
        {
            Console.WriteLine("ClasseDerivada8 Metodo1");
        }
    }

    public class ClasseDerivada2 : ClasseBase2
    {
        public sealed override void Metodo1()
        {
            Console.WriteLine("ClasseDerivada2 Metodo1");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            ClasseDerivada derivada = new ClasseDerivada();

            derivada.Metodo1();
             derivada.Metodo2();
            derivada.Metodo3();

            ClasseBase classeBase = new ClasseDerivada();

            classeBase.Metodo1();
            classeBase.Metodo2();
            classeBase.Metodo3();

            Celular c1 = new Celular("celular1", 1000, Celular.Voltagem.v110, Celular.Marcas.Apple);
            Celular c2 = new Celular("celular2", 2000, Celular.Voltagem.v110, Celular.Marcas.Apple);
            Celular c3 = new Celular("celular3", 3000, Celular.Voltagem.v110, Celular.Marcas.Apple);

            List<Celular> lista = new List<Celular>();
            lista.Add(c1);
            lista.Add(c2);
            lista.Add(c3);

            //5 metodos/funcoes.
            IEnumerable<Celular> ienumerable = lista;
            //17 metodos/funcoes
            ICollection<Celular> icollection = lista;
            //21 metodos/funcoes
            IList<Celular> ilist = lista;

            foreach (var c in ienumerable)
            {
                c.Ligar();
            }

            c1.Ligar();
            c1.Inicializar();
            c1.Desligar();

            //CLASSE ABSTRATA NAO PODE SER INSTANCIADA
            //Eletronico e1 = new Eletronico("eeee", 2000, Eletronico.Voltagem.v110);

            var t1 = new Televisao("tva", 7000, Televisao.Voltagem.v220,
                Televisao.Marcas.CCE, "10pol", "10k");

            t1.Ligar();
            t1.Inicializar();
            t1.Desligar();

            ///AULA 18/11
            RepositorioLista repositorioLista = new RepositorioLista("repo");

            repositorioLista.Adicionar(c1);
            repositorioLista.Adicionar(t1);
            repositorioLista.Adicionar(c2);

            foreach (var x in repositorioLista.ListarTodos())
            {
                Console.WriteLine(x.Nome);
            }

            repositorioLista.Remover(c1);
            repositorioLista.Remover(t1);
            repositorioLista.Remover(c2);

            RepositorioLista repositorioLista2 = new RepositorioLista("rep");

            RepositorioListaComInterface repInterface = new RepositorioListaComInterface(repositorioLista2);
            repInterface.Adicionar(c1);
            Console.Read();

        }
    }
}
