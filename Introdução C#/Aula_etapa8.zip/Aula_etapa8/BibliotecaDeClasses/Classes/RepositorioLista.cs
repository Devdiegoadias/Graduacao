﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaDeClasses.Classes
{
    public class RepositorioLista : IRepositorioLista
    {
       public RepositorioLista(string nomeRepositorio) { }

        private List<Eletronico> eletronicos = new List<Eletronico>();

        public void Adicionar(Eletronico eletronico)
        {
            eletronicos.Add(eletronico);
        }

        public void Remover(Eletronico eletronico)
        {
            eletronicos.Remove(eletronico);
        }

        public IList<Eletronico> ListarTodos()
        {
            return eletronicos;
        }
    }

    public class RepositorioListaClassConcreta
    {
        public RepositorioListaClassConcreta() { }

        public void Adicionar(Eletronico eletronico)
        {
            RepositorioLista rep = new RepositorioLista("repo");
            rep.Adicionar(eletronico);
        }

        public void Remover(Eletronico eletronico)
        {
            RepositorioLista rep = new RepositorioLista("rep");
            rep.Remover(eletronico);
        }
    }

    public class RepositorioListaComInterface
    {
        IRepositorioLista _irepositorio;
        public RepositorioListaComInterface(IRepositorioLista irepositorio)
        {
            _irepositorio = irepositorio;
        }

        public void Adicionar(Eletronico eletronico)
        {
            _irepositorio.Adicionar(eletronico);
        }

        public void Remover(Eletronico eletronico)
        {
            _irepositorio.Remover(eletronico);
        }
    }
}
