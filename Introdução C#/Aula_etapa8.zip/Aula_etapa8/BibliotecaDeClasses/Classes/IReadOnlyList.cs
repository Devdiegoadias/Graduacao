﻿namespace BibliotecaDeClasses.Classes
{
    internal interface IReadOnlyList
    {
    }
}