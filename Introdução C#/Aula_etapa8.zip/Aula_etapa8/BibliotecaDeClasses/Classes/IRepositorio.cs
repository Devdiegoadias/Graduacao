﻿using System;


namespace BibliotecaDeClasses.Classes
{
    public interface IRepositorio
    {
       public void Adicionar()
        {
            Console.WriteLine("ss");
        }
        void Remover();
    }

    public interface IRepositorioLista
    {
        void Adicionar(Eletronico eletronico);
        void Remover(Eletronico eletronico);
    }
}
