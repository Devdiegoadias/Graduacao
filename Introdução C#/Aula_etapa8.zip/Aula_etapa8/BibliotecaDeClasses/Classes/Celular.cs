﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaDeClasses.Classes
{
    public class Celular : Eletronico
    {
        private Marcas _marca;        
        private const decimal  IMPOSTO = 2;

        public enum Marcas
        {
            Apple = 1,
            Samsung = 2,
            Xiaomi = 3
        }

        public Celular(string nome, decimal valor, Voltagem voltagem, Marcas marca) : base(nome, valor, voltagem)
        {
            _marca = marca;            
        }

        public override void Ligar()
        {
            Console.WriteLine("LIGANDO TELEFONE CELULAR");
        }

        public override void Desligar()
        {
            Console.WriteLine("DESLIGANDO TELEFONE CELULAR");
        }

        public static decimal CalcularPrecoFinal(decimal valor)
        {
            return (valor * IMPOSTO);
        }

    }
}