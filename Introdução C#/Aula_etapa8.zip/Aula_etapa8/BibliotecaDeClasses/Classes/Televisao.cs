﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaDeClasses.Classes
{   
    public class Televisao:Eletronico, IRepositorio, IReadOnlyList, IServiceProvider, ICloneable
    {
        private  string _polegadas;        
        private string _resolucao;
        private Marcas _marca;
        private const decimal IMPOSTO = 3;

        public enum Marcas
        {
            Philco = 1,
            LG = 2,
            CCE = 3
        }        

        public Televisao(string nome, decimal valor, Voltagem voltagem, Marcas marca, string polegadas, string resolucao) : base(nome, valor, voltagem)
        {
            _polegadas = polegadas;
            _resolucao = resolucao;
            _marca = marca;
        }

        public override void  Ligar()
        {
            _polegadas = "";
            Console.WriteLine("LIGANDO A TELEVISAO");
        }

        public override void Desligar()
        {
            Console.WriteLine("DESLIGANDO A TELEVISAO");
        }

        public static decimal CalcularPrecoFinal(decimal valor)
        {
            return (valor * IMPOSTO);
        }

        public void Remover()
        {
            throw new NotImplementedException();
        }

        public object GetService(Type serviceType)
        {
            throw new NotImplementedException();
        }

        public object Clone()
        {
            throw new NotImplementedException();
        }
    }
}
