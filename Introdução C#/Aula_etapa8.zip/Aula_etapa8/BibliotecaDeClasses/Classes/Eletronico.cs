﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaDeClasses.Classes
{
    public abstract class Eletronico
    {
        private string _nome;
        private decimal _valor;
        private readonly Voltagem _voltagem;

        #region GetSet
        public string Nome
        {
            get
            {
                return _nome;
            }
            set
            {
                _nome = value;
            }
        }


        public decimal Valor
        {
            get
            {
                return _valor;
            }
            set
            {
                _valor = value;
            }
        }

        #endregion

        public enum Voltagem
        {
            v110 = 110,
            v220 = 220
        }      

        public Eletronico(string nome, decimal valor, Voltagem voltagem)
        {
            _nome = nome;
            _valor = valor;
            _voltagem = voltagem;
        }

        public Eletronico() {}


        public abstract void Ligar();        
        public abstract void Desligar();
        
        public void Inicializar()
        {
            //bateria, corrente eletrica, pilha etc...
            Console.WriteLine("Acionando fonte de energia");
        }
    }
}
