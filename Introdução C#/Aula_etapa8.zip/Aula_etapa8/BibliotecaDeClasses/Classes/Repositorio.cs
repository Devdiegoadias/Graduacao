﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaDeClasses.Classes
{
    public class Repositorio : IRepositorio
    {
        public Repositorio(string nomeRepositorio)
        {

        }
        
        public void Adicionar()
        {

        }

        public void Remover()
        {

        }
    }

    public class RepositorioClassConcreta
    {
        public RepositorioClassConcreta() { }

        public void ProcessarInclusao(string nomeRepositorio)
        {
            var repositorio = new Repositorio(nomeRepositorio); //chamando uma classe concreta
            repositorio.Adicionar();
        }
    }


    //utlizando interface, 'injetando' a mesma para usar apenas o que interessa (o método adicionar)
    public class RepositorioInterface
    {
        //reparem na variavel do tipo interface
        private IRepositorio _irepositorio;

        public RepositorioInterface(IRepositorio irepositorio)
        {
            _irepositorio = irepositorio;
        }

        public void ProcessarInclusao()
        {
            //aqui eu chamo o método adicionar que tem sua implementação/codificação no objeto passado no construtor da classe (essa)
            _irepositorio.Adicionar();
        }
    }
}
