﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 * Classe exemplo para o uso de interface:
 * Interface serve como contranto;
 * Interface no c# tem a mesma sintaxe que a herança  -> :
 * Na interface não existe a codificação dos métodos em sim.
 * Quando uma classe implementa uma interface (ex: class:interface), a mesma deve ter o corpo de código dos métodos da interface
 */

namespace BibliotecaDeClasses.Classes
{
    /*
    class Animal
    {
    }
    */

   public  interface ITerrestre
    {
        void Andar();
        void Morar();        
    }

    public interface IAves
    {
        void Voar();
        void Comer();
    }

    public class Aguia : IAves, ITerrestre
    {
        public void Voar()
        {
            Console.WriteLine("Sou uma águia e sei voar muito bem!");
        }

        public void Comer()
        {
            Console.WriteLine("Sou uma águia e como coelho");
        }

        public void Andar()
        {
            Console.WriteLine("Sou uma águia e ando nos Andes");
        }

        public void Morar()
        {
            Console.WriteLine("Sou uma águia e moro na Montanha");
        }
    }

    public class Galinha : IAves, ITerrestre
    {
        public void Voar()
        {
            Console.WriteLine("Sou uma galinha e não sei voar direito!");
        }
        
        public void Comer()
        {
            Console.WriteLine("Sou uma galinha e como milho");
        }

        public void Andar()
        {
            Console.WriteLine("Sou uma galinha e ando ciscando");
        }

        public void Morar()
        {
            Console.WriteLine("Sou uma galinha e moro no galinheiro");
        }
    }

    public class Dumbo : Eletronico, IAves, ITerrestre
    {
        public void Andar()
        {
            Console.WriteLine("Sou um dumbo e ando girando");
        }

        public void Comer()
        {
            Console.WriteLine("Sou um dumbo e como amendoim");
        }

        public override void Desligar()
        {
            throw new NotImplementedException();
        }

        public override void Ligar()
        {
            throw new NotImplementedException();
        }

        public void Morar()
        {
            Console.WriteLine("Sou um dumbo e moro no circo");
        }

        public void Voar()
        {
            Console.WriteLine("Sou um dumbo e vôo sem querer");
        }
    }
}
