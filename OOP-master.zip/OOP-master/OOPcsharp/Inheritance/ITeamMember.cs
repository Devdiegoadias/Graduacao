﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOPcsharp.Inheritance
{
    public interface ITeamMember
    {
        string TeamName { get; }

        void Team();
    }
}
