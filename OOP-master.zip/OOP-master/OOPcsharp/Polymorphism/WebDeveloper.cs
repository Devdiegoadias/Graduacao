﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOPcsharp.Polymorphism
{
    public class WebDeveloper : Developer
    {
        public WebDeveloper(string devLanguage) : base(devLanguage)
        {
        }
    }
}
